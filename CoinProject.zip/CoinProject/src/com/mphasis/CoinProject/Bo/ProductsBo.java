package com.mphasis.CoinProject.Bo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.CoinProject.model.Product;




@Repository
public class ProductsBo 
{
	SessionFactory sf = new Configuration().configure().buildSessionFactory();
	
	
	
	public boolean insertProduct(Product p)
	{
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(p);
		t.commit();
		s.close();
		return true;
	}
	
	public List<Product> getAllProducts() {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List <Product> li=s.createQuery("From Product").list();
		for(@SuppressWarnings("unused") Product p:li) {
			
		}
		t1.commit();
		s.close();
		
		return li;
	}
	
	public List<Product> getgoldproducts() {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List <Product> li=s.createQuery("From Product where category='gold' ").list();
		t1.commit();
		s.close();
		
		return li;
	
	
}
	
	public List<Product> getsilverproducts() {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List <Product> li=s.createQuery("From Product where category='silver' ").list();
		t1.commit();
		s.close();
		
		return li;
	
	
}
	
	public List<Product> getoldproducts() {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List <Product> li=s.createQuery("From Product where category='Old Currencies' ").list();
		t1.commit();
		s.close();
		
		return li;
	
	
}
	
	public List<Product> getforeignproducts() {
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List <Product> li=s.createQuery("From Product where category='Foreign Currency' ").list();
		t1.commit();
		s.close();
		
		return li;
	
	
}
	
//	public List<Product> getProductById(int b ) {
//		Session s=sf.openSession();
//		Transaction t1=s.beginTransaction();
//		
//		@SuppressWarnings("unchecked")
//		List <Product> li=s.createQuery("From Product where productID='Foreign Currency' ").list();
//		t1.commit();
//		s.close();
//		
//		return li;
//}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List <Product> insertOrder(int id)
	{
		
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		Query q=s.createQuery("From Product where productID=:id");  
		q.setParameter("id", id);
		List<Product> list=q.list();
		
		t1.commit();
		s.close();
		return list;
	}
	
	
	
	
	
}