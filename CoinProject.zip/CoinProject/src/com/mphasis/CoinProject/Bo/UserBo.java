package com.mphasis.CoinProject.Bo;


import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.CoinProject.model.User;

@Repository
public class UserBo {
	
	
	
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
		
		public Boolean insertTrainee(User u) {
			
					Session s=sf.openSession();
					Transaction t1=s.beginTransaction();
					s.save(u);
					t1.commit();
					s.close();
					
					
			return true;
		}

		public List<User> getAllTrainee() {
			Session s=sf.openSession();
			Transaction t1=s.beginTransaction();
			@SuppressWarnings("unchecked")
			List <User> li=s.createQuery("From User").list();
			t1.commit();
			s.close();
			
			return li;
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		public List<User> getUser(String mob){
			System.out.println(mob);
			Session s=sf.openSession();
			Transaction t1=s.beginTransaction();
			Query q=s.createQuery("From User where userMobile=:id");  
			q.setParameter("id", mob);
			List<User> list=q.list();
			
            t1.commit();
            s.close();
           
            return list;
			
            
            
			
		}
		public Boolean updatepass(String pass,String mob) {
			Session s=sf.openSession();
			Transaction t1=s.beginTransaction();
			//s.save(pass,id);
			String hql = "UPDATE UserC SET password=:pass WHERE userMobile = :id";

			@SuppressWarnings("rawtypes")
			Query query = s.createQuery(hql);
			query.setParameter("pass", pass);
			query.setParameter("id", mob);
			int rr = query.executeUpdate();

			t1.commit();
			s.close();

			if (rr != 0) {
			    return true;
			} else {
			    return true;
			}
			
		}

}
