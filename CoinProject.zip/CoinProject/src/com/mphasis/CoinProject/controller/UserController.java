package com.mphasis.CoinProject.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.CoinProject.Bo.UserBo;
import com.mphasis.CoinProject.model.User;

@RestController
public class UserController {
	
	@Autowired
	UserBo ub;
	
//	@RequestMapping("/")
//	public ModelAndView firstMethod()
//	{
//		return new ModelAndView("index");
//	}
//	
	
	@RequestMapping("/sell")
	public ModelAndView fiftyMethod()
	{
		return new ModelAndView("sell");
	}
	
	@RequestMapping("/register")
	public ModelAndView secondMethod()
	{
		return new ModelAndView("register");
	}
	
	@RequestMapping("/login")
	public ModelAndView loginmethod()
	{
		return new ModelAndView("login");
	}
	
	@RequestMapping(value="insertuser" , method = RequestMethod.POST)
	public ModelAndView thirdMethod(HttpServletRequest req) {
		String name = req.getParameter("uname");
		System.out.println(name);
		String pass = req.getParameter("upass");
		String cpass = req.getParameter("ucpass");
		String mobile = req.getParameter("umobile");
		String city = req.getParameter("ucity");
		String email = req.getParameter("uemail");
		String gender = req.getParameter("ugender");
		String dob = req.getParameter("udob");
		String squestion = req.getParameter("usecurity");
		String answer = req.getParameter("uanswer");
		DateTimeFormatter f1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate udob=LocalDate.parse(dob, f1);
		@SuppressWarnings("unused")
		String utype="User";
		if(pass.equals(cpass)) {
		User u=new User(0,name,email,mobile,pass,cpass,udob,gender,squestion,answer,city);
		ub.insertTrainee(u);
		return new ModelAndView("registersuccess");
		}
		else
		{
			return new ModelAndView("error");
		}
	}
	
	
	@RequestMapping(value="loginuser" , method = RequestMethod.POST)
	public ModelAndView fourthMethod(HttpServletRequest req) {
		ModelAndView mv= null;
		
		String username=req.getParameter("uname");
		System.out.println(username);
		String upass=req.getParameter("upass");
		System.out.println(upass);
		List <User> li=ub.getAllTrainee();
		String name="";
		int userid= 0;
		if(username.equals("admin")&&upass.equals("adm@123")) {
			return new ModelAndView("adminpage");
		}
		
		for(User u:li)
		{
			if(u.getUserMobile().equals(username)||u.getUserEmail().equals(username)) {
				if(u.getPassword().equals(upass)) {
					mv= new ModelAndView("loginsuccess");
					name=u.getUserName();
					userid=u.getUserID();
					
					break;
				}
			}
			else {
				mv= new ModelAndView("error");
			}
			
		}
		
		mv.addObject("name", name);
		mv.addObject("userid", userid);
		return mv;
		
		
	}
	
	@RequestMapping("/forgot")
	public ModelAndView forgotmethod()
	{
		return new ModelAndView("forgot");
	}
	
	@RequestMapping(value="ForgotServlet", method=RequestMethod.POST)
	public ModelAndView forgotsmethod(HttpServletRequest req)
	{
		String username=req.getParameter("id");
		List <User> li=ub.getAllTrainee();
		for(User u:li)
		{
			if(u.getUserMobile().equals(username)||u.getUserEmail().equals(username)) {
					
					return new ModelAndView("forgot1");
				
			}
		}
		
		
		return new ModelAndView("errorpage");
	}
	
	@RequestMapping(value="Forgot1Servlet" , method = RequestMethod.POST)
	public ModelAndView forgot1method(HttpServletRequest req)
	{
		String mob=req.getParameter("id");
		String dob=req.getParameter("name");
		String ans=req.getParameter("name1");
		
		List <User>li=ub.getUser(mob);
		
		for(User u:li) {
		String dob1=u.getUserDOB().toString();
		if((dob1.equals(dob))&&(u.getAnswer().equals(ans))) {
			return new ModelAndView("updatepass");
		}
			else {
				return new ModelAndView("error");
			}
		}
		return new ModelAndView("login");
		
			
		
	}
	
	@RequestMapping(value="updatesuccess",method=RequestMethod.POST)
	public ModelAndView updatepass(HttpServletRequest req) {
		String pass=req.getParameter("pass");
		String pass1=req.getParameter("pass1");
		String mob=req.getParameter("id");
		System.out.println(mob);
		@SuppressWarnings("unused")
		boolean b=false;
		if(pass.equals(pass1)) {
			b=ub.updatepass(pass,mob);
			if(b=true) {
				return new ModelAndView("updatesuccess");
			}
		}
		return new ModelAndView("errorpage");
		
	}

	
}
