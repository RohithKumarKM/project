package com.mphasis.CoinProject.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productID;
	private String category;
	private double price;
	private String productName;
	private String description;
	private String stock;
	private String period;
//	
	private String material;
	private int quantity;
	private int userid;
	
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public Product(int productID, String category, double price, String productName, String description, String stock,
			String period, String material, int quantity, int userid) {
		super();
		this.productID = productID;
		this.category = category;
		this.price = price;
		this.productName = productName;
		this.description = description;
		this.stock = stock;
		this.period = period;
		this.material = material;
		this.quantity = quantity;
		this.userid = userid;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", category=" + category + ", price=" + price + ", productName="
				+ productName + ", description=" + description + ", stock=" + stock + ", period=" + period
				+ ", material=" + material + ", quantity=" + quantity + ", userid=" + userid + "]";
	}
	
	
	
}