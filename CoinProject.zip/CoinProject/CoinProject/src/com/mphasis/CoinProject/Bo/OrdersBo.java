package com.mphasis.CoinProject.Bo;
	

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.mphasis.CoinProject.model.Orders;

	@Repository
	public class OrdersBo {

		SessionFactory sf = new Configuration().configure().buildSessionFactory();

		public boolean insertO(Orders o)
		{
			Session s = sf.openSession();
			Transaction t = s.beginTransaction();
			s.save(o);
			t.commit();
			s.close();
			return true;
		}
		
		
	}
